import { Form } from 'react-bootstrap';
export default function Campodos(props) {
    return (
        <Form.Check inline label={props.label} name ={props.name} type="radio" required />
    )
}