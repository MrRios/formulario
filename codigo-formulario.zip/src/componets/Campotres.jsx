import { Form } from 'react-bootstrap';
export default function Campotres(props) {
    return (
        <Form.Group>
            <Form.Label>{props.text}</Form.Label>
            <Form.Control as="textarea" required/>
        </Form.Group>
    )
}