import { Form } from 'react-bootstrap';
export default function Campouno(props) {
    return (
        <Form.Group>
            <Form.Label>{props.label}</Form.Label>
            <Form.Control type="text" placeholder={props.place} required />
            <Form.Control.Feedback type='invalid'>{props.feed}</Form.Control.Feedback>
            <Form.Text className="text-muted red">{props.text}</Form.Text>
        </Form.Group>
    )
}