import { useState } from 'react';
import { Button, Container, Form, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css';
import Campouno from './componets/Campouno';
import Campodos from './componets/Campodos';
import Campotres from './componets/Campotres';
import Campocuatro from './componets/Campocuatro';

function App() {

  const [valor1, setValor1] = useState ();

  const onChangevalor = function (evento) {
    setValor1(evento.target.value);
  }

  return (
    <Container>
      <Row md={12}>
      
      <Form>

        <h5>Describe React features</h5>

        <Campouno  onChange={onChangevalor} label="JSX" feed="Llene este campo de formulario" text="Campo Obligatorio" place="Respuesta" />

        <Campouno  onChange={onChangevalor} label="Component" feed="Llene este campo de formulario" text="Campo Obligatorio" place="Respuesta" />

        <Campouno  onChange={onChangevalor} label="Virtual DOM:" feed="Llene este campo de formulario" text="Campo Obligatorio" place="Respuesta" />

        <Campouno  onChange={onChangevalor} label="One-way data-binding:" feed="Llene este campo de formulario" text="Campo Obligatorio" place="Respuesta" />

        <Campouno  onChange={onChangevalor} label="Performance:" feed="Llene este campo de formulario" text="Campo Obligatorio" place="Respuesta" />
        <hr/>
        <h5>Modern Web browsers can read JSX directly</h5>
        <Campodos label="false" name="g1" r="false"/> <Campodos label="true" name="g1" r="true"/>
        <h5>3.- In a web browser a JSX file needs to be transformed into a regular JavaScript object</h5>
        <Campocuatro label="false" name="g2" r="false"/> <Campocuatro label="true" name="g2" r="true"/>
        <h5>4.- DOM stands for Document Only Module </h5>
        <Campodos label="false" name="g3" r="false"/> <Campodos label="true" name="g3" r="true"/>
        <h5>5.- The next component belongs to ES6 standards</h5>
        <Campodos label="false" name="g4" r="false"/> <Campodos label="true" name="g4" r="true"/>
        <h5>6.- The next component belongs to ES6 standards</h5>
        <Campodos label="false" name="g5" r="false"/> <Campodos label="true" name="g5" r="true"/>
        <h5>7.- The next Require declaration belongs to ES6 standards </h5>
        <Campodos label="false" name="g6" r="false"/> <Campodos label="true" name="g6" r="true"/>
        <h5>8.- The next Require declaration belongs to ES6 standards</h5>
        <Campodos label="false" name="g7" r="false"/> <Campodos label="true" name="g7" r="true"/>
        <hr/>
        <h5>9.- Describe steps to create a new React app</h5>
        <Campotres/>
        <h5>10.- Explain how lists work in React </h5>
        <Campotres/>
        <h5>11.- Write an example of simple form in React: </h5>
        <Campotres/>
        <h5>12.- Write an arrow function example: </h5>
        <Campotres/>
        <h5>13.- What is a state in React?</h5>
        <Campotres/>
        <h5>14.- What is the use of render() in React?</h5>
        <Campotres/>
        <h5>15.- How do you update the state of a component?</h5>
        <Campotres/>
        <h5>16.- What are props in React?</h5>
        <Campotres/>
        <h5>17.- How do you pass props between components? Write an example.</h5>
        <Campotres/>
        <h5>18.- How can you embed two or more components into one? Write an example.</h5>
        <Campotres/>
        <h5>19.- Explain the lifecycle methods of components</h5>
        <Campotres text="a) getInitialState()"/>
        <Campotres text="b) componentDidMount()"/>
        <Campotres text="c) shouldComponentUpdate()"/>
        <Campotres text="d) componentDidUpdate()"/>
        <Campotres text="e) componentWillUnmount()"/>
        <h5>20.- What is Redux?</h5>
        <Campotres/>
      <Button variant="primary" type="submit" >Enviar</Button>
    </Form>
    </Row>
    </Container>
    
  )
}

export default App;
